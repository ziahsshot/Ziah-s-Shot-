import { useState, useEffect, useRef } from "react";
import logo from "./logo.jpg";

const SERVICES = [
  { icon: "⬡", title: "Brand Films", desc: "Cinematic brand stories that convert viewers into believers. Every cut is intentional." },
  { icon: "◈", title: "Reels & Short-Form", desc: "High-retention edits built for the scroll. Hooks in 2 seconds, holds for 60." },
  { icon: "◉", title: "YouTube & Long-Form", desc: "Structured, paced, and gripping from open to close. No dead air. No wasted frames." },
  { icon: "✦", title: "Motion & Color", desc: "Titles, transitions, and color grades that elevate raw footage into polished content." },
];

const STEPS = [
  { num: "01", label: "Submit your footage" },
  { num: "02", label: "We craft the cut" },
  { num: "03", label: "You review & approve" },
  { num: "04", label: "Delivery in 48hrs" },
];

export default function App() {
  const [email, setEmail] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [status, setStatus] = useState("idle");
  const [waitlistCount, setWaitlistCount] = useState(312);
  const [visibleSections, setVisibleSections] = useState(new Set());
  const sectionRefs = useRef([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections((prev) => new Set([...prev, entry.target.dataset.section]));
          }
        });
      },
      { threshold: 0.12 }
    );
    sectionRefs.current.forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, []);

  async function handleJoin() {
    const trimmed = email.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!trimmed || !emailRegex.test(trimmed)) { setStatus("error"); return; }
    setStatus("loading");

    try {
      const res = await fetch("https://formspree.io/f/xvzydbln", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({
          email: trimmed,
          whatsapp: whatsapp.trim() || "Not provided",
          _subject: "New Waitlist Signup - Ziah's Shots",
          _replyto: trimmed,
        }),
      });
      if (res.ok) {
        setWaitlistCount((c) => c + 1);
        setStatus("success");
        setEmail("");
        setWhatsapp("");
      } else {
        setStatus("failed");
      }
    } catch {
      setStatus("failed");
    }
  }

  const addRef = (i) => (el) => { sectionRefs.current[i] = el; };

  return (
    <div style={{ background: "#040604", minHeight: "100vh", color: "#e8f5e0", fontFamily: "'Georgia', serif", overflowX: "hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Orbitron:wght@400;600;700;900&family=DM+Mono:wght@300;400&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #040604; }

        @keyframes fadeUp { from { opacity:0; transform:translateY(28px); } to { opacity:1; transform:translateY(0); } }
        @keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
        @keyframes logoFloat {
          0%,100% { transform:translateY(0px); filter:drop-shadow(0 0 30px rgba(57,255,20,0.6)); }
          50% { transform:translateY(-12px); filter:drop-shadow(0 0 50px rgba(57,255,20,0.9)); }
        }
        @keyframes hexSpin { from { transform:translate(-50%,-50%) rotate(0deg); } to { transform:translate(-50%,-50%) rotate(360deg); } }
        @keyframes scanline { 0% { transform:translateY(-100%); } 100% { transform:translateY(100vh); } }

        .scanline { position:fixed; inset:0; pointer-events:none; z-index:998; overflow:hidden; }
        .scanline::after { content:''; position:absolute; left:0; right:0; height:2px; background:linear-gradient(transparent,rgba(57,255,20,0.03),transparent); animation:scanline 4s linear infinite; }

        .nav { display:flex; justify-content:space-between; align-items:center; padding:24px 60px; position:fixed; top:0; left:0; right:0; z-index:100; background:linear-gradient(to bottom,rgba(4,6,4,0.98) 0%,transparent 100%); border-bottom:1px solid rgba(57,255,20,0.08); }
        .logo { font-family:'Orbitron',monospace; font-size:18px; font-weight:900; color:#e8f5e0; letter-spacing:2px; text-transform:uppercase; }
        .logo span { color:#39ff14; text-shadow:0 0 12px rgba(57,255,20,0.8); }
        .nav-btn { background:transparent; border:1px solid #39ff14; color:#39ff14; padding:10px 24px; font-family:'Orbitron',monospace; font-size:10px; letter-spacing:2px; text-transform:uppercase; cursor:pointer; transition:all 0.3s; text-shadow:0 0 8px rgba(57,255,20,0.6); box-shadow:0 0 12px rgba(57,255,20,0.15),inset 0 0 12px rgba(57,255,20,0.05); }
        .nav-btn:hover { background:rgba(57,255,20,0.1); box-shadow:0 0 24px rgba(57,255,20,0.4),inset 0 0 20px rgba(57,255,20,0.1); }

        .hero { min-height:100vh; display:grid; grid-template-columns:1fr 1fr; align-items:center; padding:120px 60px 80px; position:relative; overflow:hidden; gap:60px; }
        .hero-bg { position:absolute; inset:0; background:radial-gradient(ellipse 50% 60% at 70% 50%,rgba(57,255,20,0.05) 0%,transparent 65%),radial-gradient(ellipse 30% 40% at 10% 80%,rgba(0,180,0,0.04) 0%,transparent 60%); }
        .hex-grid { position:absolute; inset:0; opacity:0.04; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='52'%3E%3Cpolygon points='30,2 58,17 58,47 30,62 2,47 2,17' fill='none' stroke='%2339ff14' stroke-width='0.5'/%3E%3C/svg%3E"); background-size:60px 52px; }
        .hero-left { position:relative; z-index:2; }
        .hero-tag { font-family:'Orbitron',monospace; font-size:10px; letter-spacing:4px; color:#39ff14; text-transform:uppercase; margin-bottom:24px; opacity:0; animation:fadeUp 0.7s ease 0.3s forwards; text-shadow:0 0 10px rgba(57,255,20,0.6); display:flex; align-items:center; gap:12px; }
        .hero-tag::before { content:''; display:inline-block; width:30px; height:1px; background:#39ff14; box-shadow:0 0 6px rgba(57,255,20,0.8); }
        .hero-title { font-family:'Orbitron',monospace; font-size:clamp(28px,4vw,52px); font-weight:900; line-height:1.08; letter-spacing:-1px; opacity:0; animation:fadeUp 0.8s ease 0.5s forwards; }
        .hero-title .green { color:#39ff14; text-shadow:0 0 20px rgba(57,255,20,0.7),0 0 40px rgba(57,255,20,0.3); display:block; }
        .hero-sub { font-family:'Rajdhani',sans-serif; font-size:17px; color:rgba(232,245,224,0.55); max-width:420px; line-height:1.7; margin-top:24px; opacity:0; animation:fadeUp 0.8s ease 0.7s forwards; }
        .hero-divider { width:60px; height:2px; background:linear-gradient(to right,#39ff14,transparent); margin:28px 0; box-shadow:0 0 8px rgba(57,255,20,0.5); opacity:0; animation:fadeUp 0.8s ease 0.85s forwards; }

        .waitlist-stack { display:flex; flex-direction:column; gap:10px; max-width:480px; opacity:0; animation:fadeUp 0.8s ease 1s forwards; }
        .waitlist-row { display:flex; gap:0; }
        .wl-input { flex:1; background:rgba(57,255,20,0.04); border:1px solid rgba(57,255,20,0.25); border-right:none; padding:14px 20px; color:#e8f5e0; font-family:'DM Mono',monospace; font-size:13px; outline:none; transition:border-color 0.3s; }
        .wl-input:focus { border-color:rgba(57,255,20,0.7); box-shadow:0 0 12px rgba(57,255,20,0.1); }
        .wl-input::placeholder { color:rgba(232,245,224,0.25); }
        .wl-input-full { width:100%; border-right:1px solid rgba(57,255,20,0.25) !important; border-top:none; }
        .wl-btn { background:#39ff14; border:1px solid #39ff14; color:#040604; padding:14px 24px; font-family:'Orbitron',monospace; font-size:10px; letter-spacing:1.5px; text-transform:uppercase; font-weight:700; cursor:pointer; transition:all 0.3s; white-space:nowrap; }
        .wl-btn:hover { background:#55ff33; box-shadow:0 0 24px rgba(57,255,20,0.6); }
        .wl-btn:disabled { opacity:0.5; cursor:not-allowed; }

        .count-tag { font-family:'DM Mono',monospace; font-size:11px; color:rgba(57,255,20,0.6); letter-spacing:1px; margin-top:12px; opacity:0; animation:fadeUp 0.8s ease 1.2s forwards; }
        .count-tag strong { color:#39ff14; text-shadow:0 0 8px rgba(57,255,20,0.5); }
        .status-msg { font-family:'DM Mono',monospace; font-size:12px; margin-top:10px; letter-spacing:0.5px; }

        .hero-right { display:flex; justify-content:center; align-items:center; position:relative; z-index:2; opacity:0; animation:fadeIn 1.2s ease 0.8s forwards; }
        .logo-img { width:min(400px,100%); animation:logoFloat 4s ease-in-out infinite; border-radius:8px; }

        .section { padding:90px 60px; }
        .sec-label { font-family:'Orbitron',monospace; font-size:10px; letter-spacing:4px; color:#39ff14; text-transform:uppercase; margin-bottom:16px; text-shadow:0 0 8px rgba(57,255,20,0.5); }
        .sec-title { font-family:'Orbitron',monospace; font-size:clamp(24px,3.5vw,48px); font-weight:900; line-height:1.1; letter-spacing:-0.5px; }
        .sec-title .green { color:#39ff14; text-shadow:0 0 16px rgba(57,255,20,0.5); }

        .services-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:1px; margin-top:50px; border:1px solid rgba(57,255,20,0.1); }
        .service-card { padding:36px 28px; background:rgba(57,255,20,0.02); border:1px solid rgba(57,255,20,0.07); transition:all 0.4s; }
        .service-card:hover { background:rgba(57,255,20,0.06); border-color:rgba(57,255,20,0.25); box-shadow:inset 0 0 30px rgba(57,255,20,0.04),0 0 20px rgba(57,255,20,0.08); }
        .s-icon { font-size:22px; color:#39ff14; margin-bottom:18px; display:block; text-shadow:0 0 10px rgba(57,255,20,0.7); }
        .s-title { font-family:'Orbitron',monospace; font-size:13px; font-weight:700; letter-spacing:1px; margin-bottom:12px; text-transform:uppercase; }
        .s-desc { font-family:'Rajdhani',sans-serif; font-size:15px; color:rgba(232,245,224,0.5); line-height:1.65; }

        .process-section { background:rgba(57,255,20,0.02); border-top:1px solid rgba(57,255,20,0.1); border-bottom:1px solid rgba(57,255,20,0.1); }
        .steps-row { display:flex; gap:0; margin-top:50px; flex-wrap:wrap; }
        .step { flex:1; min-width:140px; padding:28px; border-left:1px solid rgba(57,255,20,0.1); }
        .step:first-child { border-left:none; }
        .step-num { font-family:'Orbitron',monospace; font-size:11px; color:#39ff14; letter-spacing:2px; margin-bottom:14px; display:block; text-shadow:0 0 8px rgba(57,255,20,0.5); }
        .step-label { font-family:'Rajdhani',sans-serif; font-size:18px; font-weight:700; }

        .cta-section { text-align:center; padding:110px 60px; background:radial-gradient(ellipse 80% 60% at 50% 50%,rgba(57,255,20,0.05) 0%,transparent 70%); border-top:1px solid rgba(57,255,20,0.1); position:relative; overflow:hidden; }
        .cta-hex { position:absolute; width:600px; height:600px; border:1px solid rgba(57,255,20,0.04); left:50%; top:50%; animation:hexSpin 30s linear infinite; clip-path:polygon(50% 0%,100% 25%,100% 75%,50% 100%,0% 75%,0% 25%); background:rgba(57,255,20,0.01); }
        .cta-title { font-family:'Orbitron',monospace; font-size:clamp(26px,4.5vw,56px); font-weight:900; line-height:1.1; letter-spacing:-0.5px; margin-bottom:20px; position:relative; z-index:2; }
        .cta-title .green { color:#39ff14; text-shadow:0 0 24px rgba(57,255,20,0.6); display:block; }
        .cta-sub { font-family:'Rajdhani',sans-serif; font-size:16px; color:rgba(232,245,224,0.45); max-width:420px; margin:0 auto 44px; line-height:1.7; position:relative; z-index:2; }
        .cta-stack { display:flex; flex-direction:column; gap:10px; max-width:480px; margin:0 auto; position:relative; z-index:2; }
        .cta-form { display:flex; gap:0; }

        .contact-section { padding:80px 60px; border-top:1px solid rgba(57,255,20,0.1); }
        .contact-cards { display:flex; gap:20px; justify-content:center; flex-wrap:wrap; margin-top:40px; }
        .contact-card { display:flex; flex-direction:column; align-items:center; gap:10px; padding:32px 40px; background:rgba(57,255,20,0.03); border:1px solid rgba(57,255,20,0.12); text-decoration:none; color:#e8f5e0; transition:all 0.3s; min-width:180px; }
        .contact-card:hover { background:rgba(57,255,20,0.08); border-color:rgba(57,255,20,0.4); box-shadow:0 0 20px rgba(57,255,20,0.1); transform:translateY(-4px); }
        .contact-icon { font-size:28px; color:#39ff14; text-shadow:0 0 12px rgba(57,255,20,0.7); }
        .contact-label { font-family:'Orbitron',monospace; font-size:10px; letter-spacing:2px; color:rgba(232,245,224,0.4); text-transform:uppercase; }
        .contact-value { font-family:'DM Mono',monospace; font-size:13px; color:#e8f5e0; }

        .footer { padding:32px 60px; border-top:1px solid rgba(57,255,20,0.1); display:flex; justify-content:space-between; align-items:center; }
        .footer-logo { font-family:'Orbitron',monospace; font-size:16px; font-weight:900; letter-spacing:2px; text-transform:uppercase; }
        .footer-logo span { color:#39ff14; text-shadow:0 0 10px rgba(57,255,20,0.6); }
        .footer-copy { font-family:'DM Mono',monospace; font-size:10px; color:rgba(232,245,224,0.25); letter-spacing:1px; }

        .reveal { opacity:0; transform:translateY(28px); transition:opacity 0.8s ease,transform 0.8s ease; }
        .reveal.visible { opacity:1; transform:translateY(0); }
        .reveal-delay-1 { transition-delay:0.1s; }
        .reveal-delay-2 { transition-delay:0.22s; }
        .reveal-delay-3 { transition-delay:0.36s; }
        .reveal-delay-4 { transition-delay:0.5s; }

        @media (max-width:768px) {
          .nav { padding:18px 20px; }
          .hero { grid-template-columns:1fr; padding:100px 20px 60px; gap:40px; }
          .hero-right { order:-1; }
          .logo-img { width:min(260px,75vw); }
          .section,.cta-section,.contact-section { padding:60px 20px; }
          .waitlist-stack { max-width:100%; }
          .wl-input { border-right:1px solid rgba(57,255,20,0.25); }
          .wl-btn { border-top:none; }
          .waitlist-row,.cta-form { flex-direction:column; }
          .steps-row { flex-direction:column; }
          .step { border-left:none; border-top:1px solid rgba(57,255,20,0.1); }
          .footer { flex-direction:column; gap:12px; text-align:center; }
          .contact-cards { flex-direction:column; align-items:center; }
        }
      `}</style>

      <div className="scanline" />

      {/* NAV */}
      <nav className="nav">
        <div className="logo">Ziah's <span>Shots</span></div>
        <button className="nav-btn" onClick={() => document.getElementById("waitlist").scrollIntoView({ behavior: "smooth" })}>
          Join Waitlist
        </button>
      </nav>

      {/* HERO */}
      <section className="hero">
        <div className="hero-bg" />
        <div className="hex-grid" />
        <div className="hero-left">
          <div className="hero-tag">Professional Video Editing</div>
          <h1 className="hero-title">
            Every Frame.<br />
            <span className="green">Perfectly Shot.</span>
          </h1>
          <p className="hero-sub">Ziah's Shots delivers premium video editing for brands, creators, and founders who demand footage that hits different.</p>
          <div className="hero-divider" />
          <div className="waitlist-stack">
            <div className="waitlist-row">
              <input className="wl-input" type="email" placeholder="Email address *" value={email}
                onChange={(e) => { setEmail(e.target.value); setStatus("idle"); }}
                onKeyDown={(e) => e.key === "Enter" && handleJoin()} />
              <button className="wl-btn" onClick={handleJoin} disabled={status === "loading"}>
                {status === "loading" ? "..." : "Reserve →"}
              </button>
            </div>
            <input className="wl-input wl-input-full" type="tel" placeholder="WhatsApp number (e.g. 09012345678)"
              value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} />
          </div>
          {status === "success" && <p className="status-msg" style={{ color: "#39ff14" }}>✓ You're locked in. We'll be in touch!</p>}
          {status === "failed" && <p className="status-msg" style={{ color: "#ff4444" }}>Submission failed. Please try again.</p>}
          {status === "error" && <p className="status-msg" style={{ color: "#ff4444" }}>Please enter a valid email address.</p>}
          <div className="count-tag"><strong>{waitlistCount.toLocaleString()}</strong> creators already waiting</div>
        </div>
        <div className="hero-right">
          <img src={logo} alt="Ziah's Shots Logo" className="logo-img" />
        </div>
      </section>

      {/* SERVICES */}
      <section className="section" ref={addRef(0)} data-section="services">
        <div className={`reveal ${visibleSections.has("services") ? "visible" : ""}`}>
          <p className="sec-label">⬡ What We Do</p>
          <h2 className="sec-title">Every format. <span className="green">Mastered.</span></h2>
        </div>
        <div className="services-grid">
          {SERVICES.map((s, i) => (
            <div key={s.title} className={`service-card reveal reveal-delay-${i + 1} ${visibleSections.has("services") ? "visible" : ""}`}>
              <span className="s-icon">{s.icon}</span>
              <div className="s-title">{s.title}</div>
              <p className="s-desc">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* PROCESS */}
      <section className="section process-section" ref={addRef(1)} data-section="process">
        <div className={`reveal ${visibleSections.has("process") ? "visible" : ""}`}>
          <p className="sec-label">◉ How It Works</p>
          <h2 className="sec-title">Simple process. <span className="green">Exceptional</span> output.</h2>
        </div>
        <div className="steps-row">
          {STEPS.map((s, i) => (
            <div key={s.num} className={`step reveal reveal-delay-${i + 1} ${visibleSections.has("process") ? "visible" : ""}`}>
              <span className="step-num">{s.num}</span>
              <div className="step-label">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* BOTTOM WAITLIST */}
      <section className="cta-section" id="waitlist" ref={addRef(2)} data-section="cta">
        <div className="cta-hex" />
        <div className={`reveal ${visibleSections.has("cta") ? "visible" : ""}`}>
          <p className="sec-label">✦ Early Access</p>
          <h2 className="cta-title">Don't miss<br /><span className="green">the first shot.</span></h2>
          <p className="cta-sub">We're onboarding a limited number of founding clients. Join the waitlist for priority access and an exclusive launch discount.</p>
          <div className="cta-stack">
            <div className="cta-form">
              <input className="wl-input" type="email" placeholder="Email address *" value={email}
                onChange={(e) => { setEmail(e.target.value); setStatus("idle"); }}
                onKeyDown={(e) => e.key === "Enter" && handleJoin()} />
              <button className="wl-btn" onClick={handleJoin} disabled={status === "loading"}>
                {status === "loading" ? "..." : "Claim Spot →"}
              </button>
            </div>
            <input className="wl-input wl-input-full" type="tel" placeholder="WhatsApp number (e.g. 09012345678)"
              value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} />
          </div>
          {status === "success" && <p className="status-msg" style={{ color: "#39ff14", marginTop: 14 }}>✓ You're locked in. We'll be in touch!</p>}
          {status === "failed" && <p className="status-msg" style={{ color: "#ff4444", marginTop: 14 }}>Submission failed. Please try again.</p>}
          {status === "error" && <p className="status-msg" style={{ color: "#ff4444", marginTop: 14 }}>Please enter a valid email address.</p>}
          <div className="count-tag" style={{ marginTop: 18 }}><strong>{waitlistCount.toLocaleString()}</strong> creators on the list</div>
        </div>
      </section>

      {/* CONTACT */}
      <section className="contact-section" ref={addRef(3)} data-section="contact">
        <div className={`reveal ${visibleSections.has("contact") ? "visible" : ""}`}>
          <p className="sec-label" style={{ textAlign: "center" }}>◈ Get In Touch</p>
          <h2 className="sec-title" style={{ textAlign: "center", marginBottom: 40 }}>Reach us <span className="green">directly.</span></h2>
          <div className="contact-cards">
            <a className="contact-card" href="mailto:ziahsshot@gmail.com">
              <span className="contact-icon">✉</span>
              <div className="contact-label">Email</div>
              <div className="contact-value">ziahsshot@gmail.com</div>
            </a>
            <a className="contact-card" href="tel:+2349018454182">
              <span className="contact-icon">✆</span>
              <div className="contact-label">Phone</div>
              <div className="contact-value">09018454182</div>
            </a>
            <a className="contact-card" href="https://wa.me/2349018454182" target="_blank" rel="noreferrer">
              <span className="contact-icon">⬡</span>
              <div className="contact-label">WhatsApp</div>
              <div className="contact-value">09018454182</div>
            </a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="footer">
        <div className="footer-logo">Ziah's <span>Shots</span></div>
        <p className="footer-copy">© 2026 Ziah's Shots Studio · All rights reserved</p>
      </footer>
    </div>
  );
}
